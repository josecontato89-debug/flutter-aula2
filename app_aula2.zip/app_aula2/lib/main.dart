import 'package:flutter/material.dart';

void main() {
  runApp(const app_aula2());
}

class app_aula2 extends StatefulWidget {
  const app_aula2({super.key});

  @override
  State<app_aula2> createState() => _app_aula2State();
}

class _app_aula2State extends State<app_aula2> {
  String mensagem = "Escolha uma opção!";

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.lightBlue,
                  foregroundColor: Colors.black,
                  minimumSize: const Size(250, 60),
                ),
                onPressed: () {
                  setState(() {
                    mensagem = "Bom Dia Aluno!";
                  });
                },

                child: const Text('Bom Dia'),
              ),

              const SizedBox(height: 20),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.black,
                  minimumSize: const Size(250, 60),
                ),
                onPressed: () {
                  setState(() {
                    mensagem = "Boa Tarde Aluno!";
                  });
                },
                child: const Text('Boa Tarde'),
              ),

              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromARGB(255, 22, 88, 2),
                  foregroundColor: Colors.black,
                  minimumSize: const Size(250, 60),
                ),
                onPressed: () {
                  setState(() {
                    mensagem = "Boa Noite Aluno!";
                  });
                },
                child: const Text('Boa Noite'),
              ),
              const SizedBox(height: 20),
              Text(mensagem, style: const TextStyle(fontSize: 28)),
            ],
          ),
        ),
      ),
    );
  }
}
